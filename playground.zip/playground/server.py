from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
def index():
    return "Welcome!"
    
@app.route('/playground')
def index():
    container = "<div class=containers></div>"
    return render_template("plsyground.html")+box*3


@app.route('/playground/<int>')
def playnumberGame(int):
     more = int
     container= "<div class= containers></div>"
     return render_template("playground.html")+container*
    

@app.route('/playground/<int>/<color>')
def playgroundcolor(num,color):
    more = int
    background = color
    box = "<div class= containers style=background-color +"background"></div>"

    return render_template("playground.html")+container*more

#template
# @app.route('/')
# def index():
#     return render_template('index.html', color="blue", number=3)

# @app.route('/<number)')
# def numbers(number):
#     return render_template('index.html', number=int(number), color="green")

# @app.route('/<number>/<color>')
# def colors_and_numbers(number, color):
#      return render_template('index.html', number=int(number), color=color)

# if name == "(__main__)":
#      app.run(debug=True)
